# NIRIKSHAN — Smart Real-Time Monitoring & Inspection

## Problem
Field inspections often depend on paper records, scattered photos and delayed reporting. This makes verification slow and reduces transparency.

## Solution
NIRIKSHAN provides a mobile-friendly inspection workflow:
- Capture site/institution details
- Capture GPS coordinates
- Attach evidence photos
- Add remarks and category
- Submit a unique inspection record through an API
- Track Submitted / Verified / Pending status

## Tech Stack
Frontend: HTML, CSS, JavaScript, Browser Geolocation API
Backend: Python, Flask, Flask-CORS
Storage: In-memory prototype (can be replaced with PostgreSQL/MySQL)

## Run
### Backend
```bash
cd backend
pip install -r requirements.txt
python app.py
```
### Frontend
Open `frontend/index.html` in a browser. For browser restrictions, serve the folder with a local server:
```bash
cd frontend
python -m http.server 5500
```
Then open http://127.0.0.1:5500

## API
GET /api/health
GET /api/inspections
POST /api/inspections

Example POST:
```json
{
  "site":"Demo Institution",
  "category":"Infrastructure",
  "remarks":"Inspection completed successfully",
  "location":{"lat":26.8467,"lon":80.9462}
}
```

## Demo flow
1. Open the dashboard.
2. Enter a site name and remarks.
3. Capture GPS.
4. Add a demo photo.
5. Submit the inspection.
6. Show the generated inspection ID and Submitted status.

## Note
This is a hackathon prototype. Production deployment should add authentication, encrypted storage, role-based access, audit logs and a real database.
