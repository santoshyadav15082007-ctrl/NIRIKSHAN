from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import uuid

app = Flask(__name__)
CORS(app)
INSPECTIONS = []

@app.get("/api/health")
def health():
    return jsonify({"status":"ok","service":"NIRIKSHAN API"})

@app.get("/api/inspections")
def list_inspections():
    return jsonify(INSPECTIONS)

@app.post("/api/inspections")
def create_inspection():
    data = request.get_json(force=True) or {}
    item = {
        "id": "NIR-" + uuid.uuid4().hex[:8].upper(),
        "site": data.get("site",""),
        "category": data.get("category",""),
        "remarks": data.get("remarks",""),
        "location": data.get("location",{}),
        "status": "Submitted",
        "created_at": datetime.utcnow().isoformat() + "Z"
    }
    INSPECTIONS.append(item)
    return jsonify(item), 201

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
